# Amex Offers Documentation

**Design team developers:** Jory Cunningham & Pat Morgan

##Hosted Prototype

#### Serve
**Dashboard**: <http://serve-offers.egdesignprototypes.com>

**Offers Landing Page**: <http://serve-offers.egdesignprototypes.com/Account/Offers>

**Offers History Page**: <http://serve-offers.egdesignprototypes.com/Account/Offers/history.html>

*username: eames | password: batgirl*

## Offers Landing Page

This page serves as the central landing page for adding offers and monitoring your previously added offers.

We are loading all offers via AJAX after initial page load. 

Offer location will be based on the user's Zip Code in their profile settings.

### Content Loaded Serve-Side on Load

As the page is loaded, the getOffersSummary API call should run for the user. This will populate the following information:

###### My Statement Credits Module
---
This number should be populated from the TotalSavings field

*If this number is over 9999.99 there should be an additional ".bigger-num" class added to the ".big-num" div. This will make the font smaller to accommodate the large number.*


###### Statements Notification Module
---

A notification is printed in the left sidebar based on the response from getOffersSummary. There are three states which can be displayed. The logic is as follows:

1. Check if "ExpiringSoonOffersCount" is greater than 0. If so, display the *"Expiring Soon"* message.
2. If no expiring offers, see if "LoadedOffersCount" is greater than 0, if so, show the *"You've added {{number}} offers"* message.
3. If no offers added, show the *"Add some offers"* message.

**For all possible notification layouts see:** <http://serve-offers.egdesignprototypes.com/Account/Offers/index-sidebar-notes.html> 

**For official text** - See copy deck 

**For more information** - See logic deck


###### Offers 101 header banner
---
**States**

The first time the user views the Offers page, the banner should be open. On every visit after that, the banner should appear closed. The two versions are included in the partials directory under header-banners.

- On *first view*, the .banner-divider and .feature-intro elements should load with the active class. The .header-banner element should have an additional .first-view class.
	- In the prototype, this happens on the standard landing page 
- On *subsequent views*, .banner-divider and .feature-intro load without active class and .header-banner loads without .first-view.
	- In the prototype, this happens on any other version of the landing-page (for instance index-error, index-empty-sets etc...)

**Field Info**

- The [[ Zip Code ]] field in the banner should be populated by the users's Zip Code in their profile settings
- The [[ First Name ]] field should have the user's first name

// **JS for this interaction located in js/offers/banner-toggle.js** //

---
### Content loaded Server Side
To speed initial page load we are retrieving all offers data as JSON retrieved via AJAX.

This JSON data is then rendered by compiling it through client-side templating using the DustJS JavaScript templating library.

These templates should be embedded as script tags (with type="text/x-template") in the footer of the page.


###### About DustJS
---
Learn about Dust JS here:

The repo: <http://linkedin.github.io/dustjs/> 

Overview: <https://github.com/linkedin/dustjs/wiki/Dust-Tutorial> 

Notes on Dust "helpers", which provide additional logic to the templates: <https://github.com/linkedin/dustjs-helpers/wiki/Helpers> 

###### About the assumed JSON
---
The templates were created using documentation from the Offers API. We are assuming a helper function in between the Offers API and the Client which will simplify the data returned from the Offer API to only the required fields.

Simplified examples of the JSON are included as sample data objects in the included "manage-offers.js" whenever AJAX data is required.

The field names used match those of the Offers API, but nesting complexity has been reduced.

The data structure can be altered as long as the variable tags are also altered in the Dust templates.

---
### About manage-offers.js

manage-offers.js should be included on the main Offers page. The JavaScript is namespaced to "manageOffers". It is heavily commented to provide instruction for each function in the manageOffers object.

It has the following dependencies which should be loaded before it is loaded:

* **link-modal.js** – Our library for rendering a "You are leaving this site" modal message when clicking external links. This script should already be in use on LearnVest links.
* **dust-full.js** – This is a combination of the main DustJS library and the Dust Helpers script from <http://linkedin.github.io/dustjs/>

---

#### AJAX Calls

There are four AJAX calls in the interactions on the page.

###### manageOffers.offerBlockTemplateGetData()
---

This function will fire immediately on page load (called by manageOffers.init() on document.ready)

It should call the getOffers API function and return all available offers to the user based on their Zip Code.

Reference the sample data in the JS which shows what should be coming back from the server.

On **success** call:

```
manageOffers.offerBlockTemplateCompile($context, data);
```

If the AJAX call returns an **empty set**, show the empty set visual by calling this function:

```
manageOffers.emptySetShow($('#offers-all-filter'));
```

If there is an **error**, show the error by firing:

```
manageOffers.errorShow($('.offer-get-error'));
```
    
###### manageOffers.addOffer() 
---

This function is bound to the add offer buttons provided with each offer listing. The AJAX call should read the "data-offer-id" attribute of the surrounding .offer div. This will have been printed into the HTML by the AJAX call which rendered the HTML.

**On Success call:**

```
manageOffers.addOfferCallback($context);
```

**If there is an error:**

```
manageOffers.errorShow($('.offer-add-error'));
```

###### manageOffers.getMoreOfferInfo()
---

The additional offer information (redemption method, terms and conditions) is not loaded until the user needs it. The user requests this information by either:

* Clicking the 'Add Offer' link
* Clicking the 'toggle' link to expand offer information

When either of these actions occur the JS will check to see if the offer information is already present (for instance if the user previously expanded the details). If it's not present, the JS will call the getOffers API by OfferId to retrieve the appropriate data.

**If there is an error:**

```
manageOffers.errorShow($('.offer-info-error'));
```

--- 

### About Offer information:

#### Standard Offer

Shows offer description and locations.

**Criteria:** All offers get this as a baseline

---

#### Promo Code

Shows a related Promo Code for an offer.

**Criteria:**  "OfferCharacterstics" has the following properties:

"CharType": "PROMO_CODE",

"CharValue": {{ promo-code-value }}

---

#### Special Link Offer
Displays a Link where users can click to redeem an offer. This link is determined by the presence of a value in "Destination URL". If there is a "DestinationURL" then the standard "MerchantURL" is suppressed.

**Criteria:**                                    
"DestinationURL" has value


###### manageOffers.offerAddedFilterTemplateGetData()
---

**This function checks for added offers.**

If there is an **error** fire:

```
manageOffers.errorShow($('.offer-get-error'));
```
If the AJAX call returns an **empty set**:

```
manageOffers.emptySetShow($('#offers-added-filter'));
```

---

### About Errors
An error state can be seen at:

<http://serve-offers.egdesignprototypes.com/Account/Offers/index-error.html>

All errors are triggered by this function:
```
manageOffers.errorShow($error)
```

$error should be a valid jquery selector that refers to the error message embedded in the HTML.

**Sample HTML**


```
<section class="message global-error offers-errors" role="alert" aria-live="assertive">
			<div class="message-inner">
				<p class="error-message offer-get-error">There has been a problem retireving your Offers. Please reload this page to try again.</p>
				<p class="error-message offer-info-error">There has been a problem retireving these Offer details. Please reload this page to try again.</p>
				<p class="error-message offer-add-error">We could not add this Offer due to an error. Please try again.</p>
			</div>
</section>
```

---
### About Empty Sets

If there are no offers for either the View All or View Added filters, an empty state appears.

**See empty states here:**

<http://serve-offers.egdesignprototypes.com/Account/Offers/index-empty-sets.html>

The button in the View Added filter empty set switches back to the view all filter.

Empty sets are pre-printed into the HTML on initial page load but are hidden by CSS.

**Show Empty Sets by calling:**
```
manageOffers.emptySetShow($emptySet);
```

- Where $emptySet is a valid jQuery selector for the the filter type being used. 
- Valid values are:

```
manageOffers.emptySetShow($('#offers-added-filter')); // View Added
manageOffers.emptySetShow($('#offers-all-filter')); // View All
```

## Offers History Page

This page has pretty minimal styling and no new javascript.

**Top Module:** This builds on existing .title-area styling. The big number on the right reflects the savings history total and comes from the API.

**Bottom Module:** This is basically a stripped down version of the existing transactions pattern. All content is purposefully greyscale and all interactivity has been removed. It's just meant to be a static representation of previous offers credits.

You can find the styling in **shared/sections/_offers.scss**

## Offers Dashboard Module

*This uses a new module pattern*

The description in the grey portion of the module has a couple different states, but only minor text changes are required. See the copy deck for examples of those states.

You can find the styling in **shared/molecules/_feature-highlight-module.scss**

## Icons

This update includes **4 new svg icons** (and 4 png fallbacks for browsers without svg support). They can be found in **images/other/offers** in both Serve and Bluebird.

- icon-plus-sign.svg & icon-plus-sign.png
- icon-complete-check.svg & icon-complete-check.png
- icon-offers-color.svg & icon-offers-color.png
- icon-offers-grey.svg & icon-offers-grey.png

