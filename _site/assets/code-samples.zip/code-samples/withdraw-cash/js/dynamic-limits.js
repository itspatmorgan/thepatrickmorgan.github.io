$(document).ready(function(){
  var dynamicLimit = {
    select: $(".js-dynamic-select"),    // jQuery obj – the select menu
    target_text: $(".js-limit-text"),   // jQuery obj – the text area that will be updated with new limits
    default_daily_limit: null,          // int – the default daily limit values pulled from data attribute on select menu
    current_daily_limit: null,          // int – the currently displayed daily limit, for checking whether to switch
    platform_brand: "",                 // string – (Serve, Bluebird, Prepaid Redcard)
    limit_msg_template: "You can withdraw up to $%val1% per day and $15,000 per month from your %val3% Account.",

    determineBrand: function() {
      if ($("body").hasClass("bb")) {
        dynamicLimit.platform_brand = "Bluebird";
      } else if ($("body").hasClass("redcard")) {
        dynamicLimit.platform_brand = "Prepaid Redcard";
      } else {
        dynamicLimit.platform_brand = "Serve";
      }
    },

    animateText: function(replacement_text) {
      dynamicLimit.target_text.fadeTo(500, 0, function() {
        dynamicLimit.target_text.text(replacement_text);
        dynamicLimit.target_text.fadeTo(500, 1);
      });
    },

    manageLimits: function(suppress_animation) {
      var replacement_text;
      var daily_limit;
      var platform_brand = dynamicLimit.platform_brand;
      var selected_option = $(".js-dynamic-select option:selected");
      var has_dynamic_limit = selected_option.is("[data-daily-limit]");

      if (has_dynamic_limit) {
        // set daily limit to the dynamic data
        daily_limit = selected_option.data("daily-limit");
      } else {
        // set daily limit to the default data
        daily_limit = dynamicLimit.default_daily_limit;
      }

      // if daily limit of selected option don't match the currently displayed value
      if (daily_limit != dynamicLimit.current_daily_limit) {
        // fill the limit msg template with new values
        replacement_text = dynamicLimit.limit_msg_template.replace("%val1%", daily_limit).replace("%val3%", platform_brand);

        // animate the text replacement (suppress animation only on the first change event of the select)
        if (!suppress_animation) {
          dynamicLimit.animateText(replacement_text);
        }
      }

      // store the value of the currently displayed daily limits
      dynamicLimit.current_daily_limit = daily_limit;
    },

    setDefaultLimits: function() {
      dynamicLimit.default_daily_limit = dynamicLimit.select.data("default-daily-limit");
    },

    setListeners: function() {
      dynamicLimit.select.on("change", function() {
        dynamicLimit.manageLimits();
      });
    },

    init: function() {
      dynamicLimit.setListeners();
      dynamicLimit.setDefaultLimits();
      dynamicLimit.determineBrand();
      dynamicLimit.manageLimits(true);
    }
  };

  dynamicLimit.init();
});
