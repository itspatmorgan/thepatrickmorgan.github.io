# RIA Withdraw Transaction Flow

> The copy in the prototype is not final. Please refer to the copy deck for finalized copy.

**Design team members:** Pat Morgan, Linda Sum, Ashley Hopkins, Scott Dzialo

## Serve Prototype
**Serve log-in –** `username: eames | password: batgirl`

###### Begin Withdrawal – [See the prototype](http://serve-ria.egdesignprototypes.com/Actions/WithdrawFunds/WithdrawCash/)

###### Begin Withdrawal with Errors – [See the prototype](http://serve-ria.egdesignprototypes.com/Actions/WithdrawFunds/WithdrawCash/index-errors.html)

###### Review Withdrawal Page – [See the prototype](http://serve-ria.egdesignprototypes.com/Actions/WithdrawFunds/WithdrawCash/review.html)

###### Review Withdrawal with Errors – [See the prototype](http://serve-ria.egdesignprototypes.com/Actions/WithdrawFunds/WithdrawCash/review-errors.html)

###### Confirmation Page – [See the prototype](http://serve-ria.egdesignprototypes.com/Actions/WithdrawFunds/WithdrawCash/complete.html)

## HTML

**Begin Withdrawal Page**
This markup also uses almost all existing patterns. Two areas to call out are the RIA logo treatment in the header, and the select menu, which supports a new javascript interaction (see the javascript section below for more detail).

**Begin Withdrawal Errors**
Standard block error and inline error treatments.

**Review Withdrawal Page**
This markup also uses almost all existing patterns. Just watchout for the RIA logo treatment again.

**Review Withdrawal Errors**
Again, standard block error and inline error treatments.

**Confirmation Page**
This page uses several new components and patterns that you can find below

- `.content-box-banner` – New full-bleed banner element for use within `.content-box` containers
- `.btn-tertiary` – New hollow button element for use on colored backgrounds
- `.btn-tertiary--print` – Variant for `.btn-tertiary` meant to show a target area for opening the browser print dialogue (contains and icon and text)

```html
  <div class="content-box-banner content-box-banner--funds-out">
    <div class="btn-tertiary btn-tertiary--print" onclick="window.print()">
      <i class="icon print-icon"></i>
      <span class="btn-tertiary__text">Print</span>
    </div>

    <div class="content-box-banner__focus-area">
      <h2>Your cash pickup reference number:</h2>
      <h1 class="page-title">1335463344443421</h1>
    </div>

    <div class="ruleset">
      <div class="rule dashed"></div>
    </div>

    <p class="content-box-banner__support-area">
      Keep this number handy — you’ll need to present it when collecting your funds at Walmart. We’ve also sent a confirmation email with this code and instructions to username@email.com.
    </p>
  </div>
```

- `.content-row` – New container that matches the typical responsive patterns of `.input-fieldset` and `.ruleset` within a `.content-box`
- `.col-8` and `.col-4` – New presentational classes from the grid system developed in the recent redesign of the Dashboard

```html
<section class="content-row">
  <!-- PICKUP INSTRUCTIONS SECTION HEADER -->
  <div class="page-title-area">
    <h1>Pickup Instructions</h1>
  </div>

  <!-- ROW CONTAINER FOR INSTRUCTIONAL CONTENT -->
  <div class="grid-row">
    <div class="col-8">
      <p class="label-text">
        It typically takes 15 minutes for your cash to be ready at any Walmart MoneyCenter within the sate you selected.
        <span class="bold">Be sure to bring your pickup code above and your valid government issued photo ID.</span>
      </p>
      <p class="label-text">
        Looking for a Walmart near you? Find one with the
        <a href="http://www.walmart.com/store/finder?location={{page.pickup-state}}&distance=50" target="_blank">
        <span class="no-wrap">Walmart Store Finder</span></a>.
      </p>
    </div>

    <div class="col-4">
      <i class="icon cash-id-icon"></i>
    </div>
  </div>
</section>
```

## SCSS & Images
**Checked in on 8/12/15 in Changeset 335836**

- Two new svg images (with png fallbacks)
    - `/images/{{brand}}/other/print-icon.svg` (print.png)
    - `/images/{{brand}}/action_flow/cash-id-icon.svg` (cash-id-icon.png)
- The scss for these images is in `/shared/atoms/icons.scss`

## Javascript

Attached you'll find a script for dynamic switching of state daily withdrawal limits (`dynamic-limits.js`). Early in the design process, we believed that several US states would have different daily and monthly limits so this script seemed necessary to provide a seamless update of information for the user as they complete the form. *However, we have since learned that the monthly limit will be the same across all states and that the only state with a distinct daily limit is Arizona (which we may still choose not to support for compliance reasons)*. So, if we need it come implementation time, the limit switching functionality is available. If not, we'll just hang on to it for a later project when it may become useful again.

#### Script Summary
The script looks for a `<select>` menu with the class `js-dynamic-select` to get its references for context (both event context and parent element context) and the default daily limit (whose value is stored in the `data-default-daily-limit` attribute.

```html
<select class="js-dynamic-select" data-widget-type="select" data-default-daily-limit="900" name="State" aria-required="true" data-validation-type="select-non-empty">
```

It then targets a `div` with class `js-limit-text` as its container for limit text replacement.

```html
<div class="field-label">
  <header>How Much?</header>
  <div class="label-text js-limit-text">
    You can withdraw up to $900 per day and $15,000 per month from your Bluebird Account.
  </div>
</div>
```

The script listens for a `change` event on `js-dynamic-select`, and if the chosen option has a distinct limit defined in an attribute called `data-daily-limit`, it will replace the limit and animate the replacement. The script covers replacement and animation for three cases:

- switching from the default to a unique limit
- switching from a unique limit back to the default
- switching between different unique limits

```html
<option value="AZ" data-daily-limit="499.99">Arizona</option>
```

More detailed and function specific comments are included in the file.

