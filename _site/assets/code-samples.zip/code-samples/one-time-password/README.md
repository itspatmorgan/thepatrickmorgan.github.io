# One Time Password Documentation

**Design team developer –** Pat Morgan

## Included Prototypes
**Serve log-in –** `username: eames | password: batgirl`

###### Edit Address
- OTP example for when a user attempts to submit a full-page form
- Expected server response html: `otp-form.html` 
- [Link to Hosted Prototype](http://serve-demo.egdesignprototypes.com/OneTimePassword/otp-form.html)

###### Edit Email
- OTP example for when a user attempts to submit an inline-editable form
- Expected server response html: `otp-inline.html` 
- [Link to Hosted Prototype](http://serve-demo.egdesignprototypes.com/OneTimePassword/otp-inline.html)

###### Log In
- OTP example for when a user attempts to log in
- Expected server response html: `otp-login.html` 
- [Link to Hosted Prototype](http://serve-demo.egdesignprototypes.com/OneTimePassword/otp-login.html)


> **Extra Note –** In this case, the div with id `#page-content` should have all class names removed (eg. login, promo, subnav) in the server response.


## Tech Expectations

- When Darwin triggers OTP, the server should respond with:
    1. Original page content wrapped in a div with class `.js-hidden-form`
    2. Data attribute called `data-otp-trigger` on the original form the user was attempting to submit
    3. OTP content inside of a div with class `.js-otp`

## Javascript

- `otp.js` – Core OTP experience
    - Code is heavily commented to explain the intention of each function
- `validation.js` – A few extra lines for OTP code input validation
    - Lines 42-50 & 130-134 

```js
    // New OTP code for jQuery Validation //
    // ********************************** //

    $("#js-otp-submit-code").validate({
        messages: {
            verification: "Please enter a 6 digit verification code"
        },

        errorPlacement: function(error, element) {
            error.appendTo( element.siblings(".field-validation-error") );
        }
    });

    $('#verification').keyup(function () {
      if (this.value.match(/[^[$,.0-9]/g)) {
        this.value = this.value.replace(/[^[$,.0-9]/g, '');
      }
    });
```
## HTML

- `otp-home.html` – Channel select screen US (select either phone or email)
- `otp-home-mex.html` – Channel screen MX (only phone)
- `otp-code-entry.html` – Submit OTP code screen
    - `screen-header.html` – Entry screen header text (for all 3 scenarios)
    - `screen-form.html` – Entry screen form components
    - `screen-footnotes.html` – Entry screen footnotes
- `error-attempts.html` – If user has exhausted code submission attempts
- `error-requests.html` – If user has exhausted OTP verification requests

## SCSS

Minimal styling changes. Main addition was a section of classes to serve as hooks for Javascript based OTP navigation.

- **TFS Changeset –**
- `shared/molecules/forms.scss` – Lines 193-207
- `shared/atoms/icons.scss` – Lines 331-358

```sass

    // JS hooks for OTP experience //
    // *************************** //

    .js-hidden-form,
    .js-otp-entry-screen,
    .js-otp-channel-text,
    .js-otp-error {
        display: none;
    }

    .content-box .js-otp-error.message {
        display: none;
    }

    .js-otp-channel-text.active {
        display: block;
    }
    
    
    // Icons                       //    
    // *************************** //
    
    .icon.otp {
      background-repeat: no-repeat;
      height: 30px;
      width: 25px;
      margin-top: 3px;
      margin-right: 10px;

    	@include mq(medium-only) {
    		display: none;
    	}
    }

    .icon.otp-sms {
      background-image: url($relative-image-file-path + "other/login/otp-sms.svg");
    }

    .icon.otp-email {
      background-image: url($relative-image-file-path + "other/login/otp-email.svg");
    }
```
