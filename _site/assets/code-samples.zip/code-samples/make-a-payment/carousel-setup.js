var Serve = Serve || {};

// This module is meant to house initialization of Carousels implemented with the Slick.js library
// Since carousel implementation will vary on a case by case basis,
// this module should grow and be adapted to match any additional requirements
// presented by the new carousel

Serve.CarouselSetup = (function () {

  var constants = {
    carousel_container: $(".carousel__container"),
    carousel_control_prev: ".js-carousel-control--prev",
    carousel_control_next: ".js-carousel-control--next"
  };

  var default_settings = {
    prevArrow: constants.carousel_control_prev,
    nextArrow: constants.carousel_control_next,
    infinite: false
  };

  var go_to_settings = {
    infinite: false,
    slidesToShow: 1,
    speed: 600,
    arrows: false,
    fade: true,
    swipe: false,
    adaptiveHeight: true
  };

  var runSlick = function () {
    constants.carousel_container.slick(default_settings);
  };

  var runSlickGoTo = function () {
    constants.carousel_container.slick(go_to_settings);
  };

  var init = function () {
    if (constants.carousel_container) {

      if (constants.carousel_container.data("carousel-type") === "go-to") {
        runSlickGoTo();
      } else {
        runSlick();
      }
    }
  };

  return {
    init: init,
    constants: constants
  };
} ());


// This is a particular instance of the Slick.js Carousel
// Used for feature education pages and expandable header areas

Serve.EducationCarousel = (function () {

  var constants = Serve.CarouselSetup.constants;

  var elements = {
    toggles: $(".js-carousel-control"),
    indicators: $(".js-indicator")
  };

  var updateActiveToggle = function ($clicked_toggle) {
    // Remove all active toggles
    elements.toggles.removeClass('active');
    // Update the clicked toggle to active
    $clicked_toggle.addClass("active");
  };

  var updateActiveIndicator = function (index) {
    var $related_indicator = $(elements.indicators.get(index));

    // If the related indicator isn't active,  
    if (!$related_indicator.hasClass("active")){
      // Remove all active indicators,
      elements.indicators.removeClass("active");
      // Then update the related indicator to active
      $related_indicator.addClass("active");
    }
  };

  var setToggleEvents = function() {
    // Loop through toggle elements in elements.toggles array

    elements.toggles.each(function (index) {
      // On click of a toggle,
      $(this).on('click', function () {
        // Update the active toggle
        updateActiveToggle($(this));
        // Go to the related index slide in the Slick Carousel
        constants.carousel_container.slick('slickGoTo', index);
        // Update the active indicator
        updateActiveIndicator(index);
      });
    });
  };

  var init = function () {
    setToggleEvents();
  };
 
  return {
    init: init
  };
} ());


$(function () {
  Serve.CarouselSetup.init();
  Serve.EducationCarousel.init();
});
