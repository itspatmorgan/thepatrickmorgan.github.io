# Make a Payment Documentation

**Design team members:** Pat Morgan, Linda Sum, Ashley Hopkins, Scott Dzialo

## Serve Prototype
**Serve log-in –** `username: eames | password: batgirl`

**Landing Page**: <http://serve-billpay.egdesignprototypes.com/MakeAPayment/Landing/unengaged.html>
